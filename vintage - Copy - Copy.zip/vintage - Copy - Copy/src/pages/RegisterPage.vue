<template>
  <div class="auth-page register-page">
    <header class="auth-header">
      <button class="top-link" type="button" @click="goToRegister">{{ t('register') }}</button>
      <div class="brand-block" @click="goHome">
        <img src="@/assets/img/LogoHorizontal.png" alt="Vintage logo" class="brand-logo" />
      </div>
      <button class="language-switch" type="button" @click="toggleLanguage">
        {{ language }} <span>▾</span>
      </button>
    </header>

    <main class="auth-main">
      <div class="auth-card register-card">
        <div class="card-header">
          <h1>{{ t('signUp') }}</h1>
          <button type="button" class="close-btn" @click="goHome" :aria-label="t('close')">×</button>
        </div>

        <p class="subtitle">{{ t('enterDetails') }}</p>
        <p v-if="errorMessage" class="form-error">{{ t(errorMessage) }}</p>

        <form @submit.prevent="handleRegister">
          <div class="field-group">
            <label for="full-name">{{ t('fullName') }} <span class="required">*</span></label>
            <input id="full-name" v-model="form.fullName" type="text" :placeholder="t('enterFullName')" required />
          </div>

          <div class="field-group">
            <label for="username">{{ t('username') }} <span class="required">*</span></label>
            <input id="username" v-model="form.username" type="text" :placeholder="t('enterUsername')" required />
          </div>

          <div class="field-group">
            <label for="email">{{ t('email') }} <span class="required">*</span></label>
            <input id="email" v-model="form.email" type="email" :placeholder="t('enterEmail')" required />
          </div>

          <div class="field-group">
            <label for="password">{{ t('password') }} <span class="required">*</span></label>
            <div class="password-wrap">
              <input
                id="password"
                v-model="form.password"
                :type="showPassword ? 'text' : 'password'"
                :placeholder="t('enterPassword')"
                required
              />
              <button type="button" class="password-toggle" @click="showPassword = !showPassword" :aria-label="t('togglePasswordVisibility')">
                <span>{{ showPassword ? '🙈' : '👁' }}</span>
              </button>
            </div>
          </div>

          <div class="field-group">
            <label for="confirm-password">{{ t('confirmationPassword') }} <span class="required">*</span></label>
            <div class="password-wrap">
              <input
                id="confirm-password"
                v-model="form.confirmPassword"
                :type="showConfirmPassword ? 'text' : 'password'"
                :placeholder="t('enterPassword')"
                required
              />
              <button type="button" class="password-toggle" @click="showConfirmPassword = !showConfirmPassword" :aria-label="t('togglePasswordVisibility')">
                <span>{{ showConfirmPassword ? '🙈' : '👁' }}</span>
              </button>
            </div>
          </div>

          <label class="checkbox-row">
            <input v-model="form.agree" type="checkbox" required />
            <span>
              {{ t('agreeTerms') }} <a href="#">{{ t('termsConditions') }}</a>; {{ t('andConfirmRead') }}
              <a href="#">{{ t('privacyPolicy') }}</a>.
            </span>
          </label>

          <button class="primary-btn" type="submit" :disabled="isSubmitting">
            {{ isSubmitting ? t('pleaseWait') : t('signUp') }}
          </button>
        </form>
      </div>
    </main>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { mapAuthError, registerAccount } from '@/services/auth'
import { useI18n } from '@/services/i18n'

const router = useRouter()
const showPassword = ref(false)
const showConfirmPassword = ref(false)
const { language, t, toggleLanguage } = useI18n()
const isSubmitting = ref(false)
const errorMessage = ref('')
const form = reactive({
  fullName: '',
  username: '',
  email: '',
  password: '',
  confirmPassword: '',
  agree: false,
})

function goHome() {
  router.push({ name: 'home' })
}

function goToRegister() {
  router.push({ name: 'register' })
}

async function handleRegister() {
  errorMessage.value = ''

  if (!form.fullName || !form.username || !form.email || !form.password || !form.confirmPassword) {
    return
  }

  if (form.password.length < 6) {
    errorMessage.value = 'passwordMinLength'
    return
  }

  if (form.password !== form.confirmPassword) {
    errorMessage.value = 'passwordsMustMatch'
    return
  }

  isSubmitting.value = true
  try {
    await registerAccount({
      fullName: form.fullName,
      username: form.username,
      email: form.email,
      password: form.password,
    })
    router.push({ name: 'success-register' })
  } catch (error) {
    errorMessage.value = mapAuthError(error)
  } finally {
    isSubmitting.value = false
  }
}
</script>

<style scoped>
* {
  box-sizing: border-box;
}

.auth-page {
  min-height: 100vh;
  background: #f1f1f1;
  color: #2f2f2f;
  font-family: 'Segoe UI', Tahoma, sans-serif;
}

.auth-header {
  height: 72px;
  background: #1f1f1f;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px 0 18px;
  color: white;
}

.top-link {
  background: transparent;
  border: none;
  color: #f4f4f4;
  font-size: 16px;
  line-height: 1;
  cursor: pointer;
  padding: 0;
  font-weight: 500;
}

.brand-block {
  display: flex;
  align-items: center;
  margin-left: 10px;
  margin-right: auto;
  cursor: pointer;
}

.brand-logo {
  display: block;
  height: 28px;
  width: auto;
  object-fit: contain;
}

.language-switch {
  background: transparent;
  border: none;
  color: #dfe3e6;
  font-size: 15px;
  cursor: pointer;
  padding: 0;
  font-weight: 500;
}

.auth-main {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: calc(100vh - 72px);
  padding: 32px 16px;
}

.auth-card {
  width: min(100%, 420px);
  background: rgba(255, 255, 255, 0.45);
  border: 1px solid #d7d7d7;
  border-radius: 8px;
  padding: 24px 26px 20px;
  box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.02);
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
}

.register-card h1 {
  margin: 0;
  text-align: center;
  font-size: 22px;
  font-weight: 500;
  color: #2f2f2f;
}

.close-btn {
  position: absolute;
  right: 0;
  top: 0;
  border: none;
  background: transparent;
  font-size: 28px;
  color: #707070;
  cursor: pointer;
  line-height: 1;
}

.subtitle {
  margin: 8px 0 18px;
  text-align: center;
  color: #666;
  font-size: 14px;
}

.form-error {
  margin: -8px 0 14px;
  color: #b42318;
  font-size: 13px;
  text-align: center;
}

.primary-btn:disabled {
  opacity: 0.7;
  cursor: not-allowed;
}

.field-group {
  margin-bottom: 18px;
}

.field-group label {
  display: block;
  margin-bottom: 8px;
  font-size: 14px;
  color: #2f2f2f;
  font-weight: 600;
}

.required {
  color: #d75d5d;
}

.field-group input {
  width: 100%;
  height: 42px;
  border: 1px solid #d2d2d2;
  border-radius: 4px;
  background: rgba(255, 255, 255, 0.3);
  padding: 10px 12px;
  font-size: 14px;
  color: #333;
  outline: none;
}

.field-group input:focus {
  border-color: #2ab3c1;
  box-shadow: 0 0 0 2px rgba(42, 179, 193, 0.1);
}

.password-wrap {
  position: relative;
}

.password-wrap input {
  padding-right: 42px;
}

.password-toggle {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  border: none;
  background: transparent;
  color: #777;
  font-size: 16px;
  cursor: pointer;
}

.checkbox-row {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  margin: 14px 0 18px;
  font-size: 12px;
  color: #4d4d4d;
  line-height: 1.5;
}

.checkbox-row input {
  width: 16px;
  height: 16px;
  margin-top: 2px;
  accent-color: #1ab0c5;
}

.checkbox-row a {
  color: #1ca8c7;
  text-decoration: underline;
}

.primary-btn {
  width: 100%;
  border: none;
  border-radius: 4px;
  background: #1ab0c5;
  color: white;
  height: 44px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: opacity 0.2s ease;
}

.primary-btn:hover {
  opacity: 0.95;
}

@media (max-width: 520px) {
  .auth-header {
    padding: 0 16px;
  }

  .brand-name {
    font-size: 22px;
  }

  .auth-card {
    padding: 20px 18px 18px;
  }
}
</style>
